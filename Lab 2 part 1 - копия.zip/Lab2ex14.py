import numpy as np
import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(1)
def heptastar(n,length):
    anglpoly = 180 * (n-2)/n
    for i in range(1, n+1):
        t.forward(length)
        t.left(180-anglpoly/3)
t.right(180)
heptastar(11,100)
t.penup()
t.goto(-120, -120)
t.pendown()
heptastar(5, 100)