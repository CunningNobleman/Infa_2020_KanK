import numpy as np
import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(1)
def drawrightpoly(n,length):
    for i in range(1, n):
        t.forward(length)
        t.left(180 - 180*(n-2)/n)
    t.forward(length)
    
for j in range(3, 10):
    t.left(180 - 90*(j-2)/j)
    drawrightpoly(j, 2*(30+(j-3)*30)*(np.sin(np.pi/j)))
    t.right((90*(j-2)/j))
    t.penup()
    t.forward(30)
    t.pendown()
