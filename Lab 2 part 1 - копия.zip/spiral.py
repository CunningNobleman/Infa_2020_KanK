import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(1)
for i in range(1, 1000):
    t.forward(10 + i)
    t.left(10 + i)
    
