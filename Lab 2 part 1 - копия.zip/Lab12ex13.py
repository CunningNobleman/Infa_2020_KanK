import numpy as np
import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(0.5)
def arc(n,length):
    i = 0
    while i < n/2:
        t.forward(length)
        t.left(180 - 180*(n-2)/n)
        i += 1
    t.forward(length)
def drawrightpoly(n,length):
    for i in range(1, n):
        t.forward(length)
        t.left(180 - 180*(n-2)/n)
    t.forward(length)
t.color("red", "green")
t.begin_fill()
drawrightpoly(100,5)
t.end_fill()
t.penup()
t.goto(-35, 80)
t.pendown()
t.color("red", "yellow")
t.begin_fill()
drawrightpoly(100,1)
t.end_fill()
t.penup()
t.goto(35, 80)
t.pendown()
t.begin_fill()
drawrightpoly(100,1)
t.end_fill()
t.penup()
t.goto(-35,45)
t.width(3)
t.right(90)
t.pendown()
arc(100, 2)