import numpy as np
import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(1)
def drawrightpoly(n,length):
    for i in range(1, n):
        t.forward(length)
        t.left(180 - 180*(n-2)/n)
    t.forward(length)
for i in range(1, 10):
    drawrightpoly (100, 5)
    t.left(60)
    i += 1