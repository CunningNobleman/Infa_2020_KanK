import numpy as np
import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(1)
def drawrightpoly(n,length,k):
    for i in range(1, n):
        t.forward(length)
        t.left(((-1)**k)*(180 - 180*(n-2)/n))
    t.forward(length)
for i in range(0, 20):
    drawrightpoly(100, 5+5*i, i)
    drawrightpoly(100, 5+5*i, i+1)
    i += 1

