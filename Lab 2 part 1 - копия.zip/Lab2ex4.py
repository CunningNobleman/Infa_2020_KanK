import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(1)
i = 1
def drawsquare(length):
    t.forward(length)
    t.left(90)
    t.forward(length)
    t.left(90)
    t.forward(length)
    t.left(90)
    t.forward(length)
    t.left(90)

while i < 25:
    drawsquare(100*i)
    t.penup()
    t.goto(-30*i, -30*i)
    t.pendown()
    i += 1
    
  
