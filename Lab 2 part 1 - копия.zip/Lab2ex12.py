import numpy as np
import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(1)
def drawrightpoly(n,length):
    i = 0
    while i < n/2:
        t.forward(length)
        t.left(180 - 180*(n-2)/n)
        i += 1
    t.forward(length)
for j in range(0, 10):
    drawrightpoly(100, 5)
    drawrightpoly(100, 1)
    j += 1