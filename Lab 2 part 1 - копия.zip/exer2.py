import turtle
turtle.shape('turtle')
i = 0
turtle.speed(0.05)
while i < 1000:
    turtle.forward(50)
    turtle.left(180*(1000-2)/1000)
    i +=1
