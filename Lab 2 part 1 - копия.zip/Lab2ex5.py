import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(1)
for i in range(1, 6):
    t.forward(80)
    t.left(180)
    t.forward(80)
    t.left(180)
    t.left(360/5)
    i += 1