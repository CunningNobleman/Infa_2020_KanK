from random import *
import turtle
turtle.shape('turtle')
i = 0
turtle.speed(2)
while i < 1000:
    turtle.goto(randint(0, 100), randint(0, 100))
    turtle.left(randint(-180, 180))
    i +=1
